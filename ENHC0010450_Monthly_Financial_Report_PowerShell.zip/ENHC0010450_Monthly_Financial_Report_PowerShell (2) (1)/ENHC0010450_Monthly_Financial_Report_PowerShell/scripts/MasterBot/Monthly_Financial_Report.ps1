########################################################################################
# Creating folder path constant
########################################################################################
$botFolderPath = (Resolve-Path "\ADC Automation\ENHC0010450_Monthly_Financial_Report_PowerShell").Path
$confFolderPath = Join-Path -Path $botFolderPath -ChildPath "conf"
$configFolderPath = Join-Path -Path $confFolderPath -ChildPath "Config"
$configFilePath = Join-Path -Path $configFolderPath -ChildPath "config.json"
$configData = Get-Content -Path $configFilePath | ConvertFrom-Json
$credsFolderPath = Join-Path -Path $confFolderPath -ChildPath "Creds"
$licenseFolderPath = Join-Path -Path $confFolderPath -ChildPath "License"
$inputFolderPath1 = Join-Path -Path $botFolderPath -ChildPath "input"
$input1 = Join-Path -Path $inputFolderPath1 -ChildPath "8_Inventory_Report_20240131_V1.1.xlsx"
$input2 = Join-Path -Path $inputFolderPath1 -ChildPath "8_Inventory_Report_20231231_V1.1.xlsx"
$outputFolderPath = Join-Path -Path $botFolderPath -ChildPath "output"
$outputResult = Join-Path -Path $outputFolderPath -ChildPath "Compared_Results.xlsx"
$logFolderPath = Join-Path -Path $botFolderPath -ChildPath "log"
$scriptsFolderPath = Join-Path -Path $botFolderPath -ChildPath "scripts"
$masterbotFolderPath = Join-Path -Path $scriptsFolderPath -ChildPath "MasterBot"
$microbotFolderPath = Join-Path -Path $scriptsFolderPath -ChildPath "MicroBots"
 
Write-Host $inputFolderPath1
 
# Get data from config.json file
$configFile = Get-content -Path $configFilePath |  ConvertFrom-Json
 
# Define log microbot
$logEntryMicroBotFilePath =  Join-Path -Path $microbotFolderPath -ChildPath "logentry.ps1"
 
# Define other microbot
#$driveSpaceMicroBotFilePath = Join-Path -Path $microbotFolderPath -ChildPath "driveSpace.ps1"
#$tcpTestMicroBotFilePath = Join-Path -Path $microbotFolderPath -ChildPath "tcpTest.ps1"
 
# Define key and license file path
$secretkeyFIlePath = Join-Path -Path $credsFolderPath -ChildPath "secretkey.txt"
$vectorkeyFilePath = Join-Path -Path $credsFolderPath -ChildPath "vectorkey.txt"
$licenseFilePath = Join-Path -Path $licenseFolderPath -ChildPath "license.txt"
 
# Output file destination
#$outputFilePath = Join-Path -Path $outputFolderPath -ChildPath $configFile.outputFileName
$outputLogFilePath = Join-Path -Path $logFolderPath -ChildPath $configFile.logFileName
 
########################################################################################
# Decrypting key and password
########################################################################################
 
function decryptkey {
    param (
        [string]$filePath
    )
    [Byte[]] $uniqueKey = (5, 7, 82, 19, 252, 25, 7, 88, 19, 253, 11, 254, 3, 10, 15, 20)
    $output = Get-Content $filePath -Raw | ConvertTo-SecureString -Key $uniqueKey
    $decryptedText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($output))
    return $decryptedText
}
 
########################################################################################
# Checking License
########################################################################################
$secretKey = decryptkey -filePath $secretkeyFIlePath
$vectorKey = decryptkey -filePath $vectorkeyFilePath
$currentDate = Get-Date
$encryptionKey = [System.Text.Encoding]::UTF8.GetBytes($secretKey)
$ivBytes = [System.Text.Encoding]::UTF8.GetBytes($vectorKey)
$encryptedLicenseInfo = Get-Content -Path $licenseFilePath -Encoding Byte
$decryptedLicenseInfo = $null
try {
    $decryptedLicenseInfo = [System.Security.Cryptography.Aes]::Create() | ForEach-Object {
        $_.Key = $encryptionKey
        $_.IV = $ivBytes
        $_.Mode = [System.Security.Cryptography.CipherMode]::CBC  # Use CBC mode
        $_.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
        $_.CreateDecryptor().TransformFinalBlock($encryptedLicenseInfo, 0, $encryptedLicenseInfo.Length)
    }
    if ($decryptedLicenseInfo) {
        $decryptedLicenseInfo = [System.Text.Encoding]::UTF8.GetString($decryptedLicenseInfo)
        $licenseData = $decryptedLicenseInfo | ConvertFrom-Json
        if ([DateTime]::Parse($licenseData.StartDate) -le $currentDate -and [DateTime]::Parse($licenseData.ExpiryDate) -ge $currentDate) {
            $daysRemaining = [math]::Ceiling(([DateTime]::Parse($licenseData.ExpiryDate) - $currentDate ).Totaldays)
            Write-Output "Days Remaining: $daysRemaining"
            & $logEntryMicroBotFilePath "SUCCESS - License Validation Complete!! Valid From: $(Get-Date $licenseData.StartDate -Format "dd-MMM-yyyy"); Until: $(Get-Date $licenseData.ExpiryDate -Format "dd-MMM-yyyy"); Remaining Days: $daysRemaining" -LogFile $outputLogFilePath
        }
        elseif ([DateTime]::Parse($licenseData.StartDate) -lt $currentDate) {
        }
    }
    else {
        Write-Output "License has expired."
        & $logEntryMicroBotFilePath "ERROR - License Expired!!" -LogFile $outputLogFilePath
        exit
    }
}
catch {
    Write-Output "An error occurred while decrypting the license: $_append"
    & $logEntryMicroBotFilePath "ERROR -  While Loading License File!!" -LogFile $outputLogFilePath
    exit
}
 
########################################################################################
# Importing MicroBot
########################################################################################
<#try{
    . "$driveSpaceMicroBotFilePath"
    . "$tcpTestMicroBotFilePath"
}
catch {
    Write-Output "ERROR - While Importing MicroBots"
    & $logEntryMicroBotFilePath "ERROR - MicroBots Not Found!!" -LogFile $outputLogFilePath
}#>
 
########################################################################################
# MasterBot
########################################################################################
 
 
 
# MasterBoT Code is here
 
# Function to compare Excel files and create a new Excel file
# Import the ImportExcel module
try {
    Import-Module ImportExcel

    # Load the input Excel files
    $inputExcelData1 = Get-ExcelSheetInfo -Path $input1
    $inputExcelData2 = Get-ExcelSheetInfo -Path $input2

    # Define the column names you want to filter on
    $columnC = $configData.ColumnC
    $columnAE = $configData.ColumnAE
    $columnAQ = $configData.ColumnAQ

    # Define the filter criteria
    $classCriteria = $configData.ClassCriteria
    $osSupportTeamCriteria = $configData.OSSupportTeamCriteria
    $slaNameCriteria = $configData.SLANameCriteria

    # Filter the data for each sheet in input2
    $hasDataInput2 = $false
    foreach ($sheet in $inputExcelData2) {
        $sheetName = $sheet.Name
        $excelData = Import-Excel -Path $input2 -WorksheetName $sheetName -HeaderRow 3
        if ($excelData) {
            $hasDataInput2 = $true
            $filteredData = $excelData | Where-Object {
                $_.$columnC -eq $classCriteria -and
                ($osSupportTeamCriteria -contains $_.$columnAE) -and
                $_.$columnAQ -ne $slaNameCriteria # Exclude data based on SLA Name criteria
            }

            # Overwrite the original data with filtered data
            $filteredData | Export-Excel -Path $input2 -WorksheetName $sheetName -AutoSize -FreezeTopRow -ClearSheet -ErrorAction SilentlyContinue
        }
    }

    if (-not $hasDataInput2) {
        Write-Host "Input Excel file '$input2' is empty. Adding all data from '$input1' to 'AddedEntries' worksheet."
        $input1Data = Import-Excel -Path $input1 -HeaderRow 1 -ErrorAction Stop
        $input1Data | Export-Excel -Path $outputResult -WorksheetName 'AddedEntries' -AutoSize -FreezeTopRow -Show
        exit
    }

    # Filter the data for each sheet in input1
    $hasDataInput1 = $false
    foreach ($sheet in $inputExcelData1) {
        $sheetName = $sheet.Name
        $excelData = Import-Excel -Path $input1 -WorksheetName $sheetName -HeaderRow 3
        if ($excelData) {
            $hasDataInput1 = $true
            $filteredData = $excelData | Where-Object {
                $_.$columnC -eq $classCriteria -and
                ($osSupportTeamCriteria -contains $_.$columnAE) -and
                $_.$columnAQ -ne $slaNameCriteria # Exclude data based on SLA Name criteria
            }

            # Overwrite the original data with filtered data
            $filteredData | Export-Excel -Path $input1 -WorksheetName $sheetName -AutoSize -FreezeTopRow -ClearSheet -ErrorAction SilentlyContinue
        }
    }

    if (-not $hasDataInput1) {
        Write-Host "Input Excel file '$input1' is empty."
        exit
    }

    # Load Excel files
    $file1 = Import-Excel -Path $input2 -HeaderRow 1 -ErrorAction Stop
    $file2 = Import-Excel -Path $input1 -HeaderRow 1 -ErrorAction Stop

    # Define the columns to keep
    $COLOUMN1 = $configData.COLOUMN1
    $COLOUMN2 = $configData.COLOUMN2
    $COLOUMN3 = $configData.COLOUMN3
    $COLOUMN4 = $configData.COLOUMN4
    $COLOUMN5 = $configData.COLOUMN5
    $columnsToKeep = @($COLOUMN1,$COLOUMN2,$COLOUMN3,$COLOUMN4,$COLOUMN5)

    # Select only the specified columns
    $file1 = $file1 | Select-Object $columnsToKeep
    $file2 = $file2 | Select-Object $columnsToKeep

    # Define columns to compare
    $columnsToCompare = $file1[0].PSObject.Properties.Name

    # Initialize arrays to store added and deleted entries
    $addedEntries = @()
    $deletedEntries = @()

    # Compare each row in file2 with file1 to find added entries
    foreach ($row2 in $file2) {
        $foundMatch = $false
        foreach ($row1 in $file1) {
            $match = $true
            foreach ($col in $columnsToCompare) {
                if ($row2.$col -ne $row1.$col) {
                    $match = $false
                    break
                }
            }
            if ($match) {
                $foundMatch = $true
                break
            }
        }
        if (-not $foundMatch) {
            $addedEntries += $row2
        }
    }

    # Compare each row in file1 with file2 to find deleted entries
    foreach ($row1 in $file1) {
        $foundMatch = $false
        foreach ($row2 in $file2) {
            $match = $true
            foreach ($col in $columnsToCompare) {
                if ($row1.$col -ne $row2.$col) {
                    $match = $false
                    break
                }
            }
            if ($match) {
                $foundMatch = $true
                break
            }
        }
        if (-not $foundMatch) {
            $deletedEntries += $row1
        }
    }

    # Remove existing output file if it exists
    if (Test-Path $outputResult) {
        Remove-Item $outputResult -Force
    }

    # Check if both added and deleted entries arrays are empty
    if ($addedEntries.Count -eq 0 -and $deletedEntries.Count -eq 0) {
        Write-Host "No changes detected between input files. Creating an empty output Excel file."
        New-Item -Path $outputResult -ItemType File -Force | Out-Null
    } else {
        # Export added and deleted entries to separate sheets in a new Excel file
        $addedEntries | Export-Excel -Path $outputResult -WorksheetName 'AddedEntries' -AutoSize -FreezeTopRow -Show
        $deletedEntries | Export-Excel -Path $outputResult -WorksheetName 'DeletedEntries' -AutoSize -FreezeTopRow -Show

        Write-Host "Comparison completed. Check the output Excel file for added and deleted entries."
    }
} catch {
    Write-Host "An error occurred: $_"
}

# Define the sender's Gmail credentials
$smtpServer = $configData.SMTPServer
$smtpPort = $configData.smtpPort
$senderEmail = $configData.SenderEmail
$senderPassword = ConvertTo-SecureString $configData.SMTPPassword -AsPlainText -Force
$recipientEmail = $configData.SupportTeamEmail
$result="True"
if($result -eq "True"){
$email_subject= $configData.messageSubjectFailure
$email_body= $configData.MailBody
}
else{
$email_subject="failure"
$email_body="Failure sending mail"
}
 
try {
    $email = New-Object System.Net.Mail.MailMessage
    $email.From = $senderEmail
    $email.To.Add($recipientEmail)
    $email.Subject = $email_subject
    $email.Body = $email_body
    $email.Attachments.Add($outputResult)
    # Set up the SMTP client
    $SMTPClient = New-Object System.Net.Mail.SmtpClient
    $SMTPClient.Host = $smtpServer
    $SMTPClient.Port = $smtpPort
    $SMTPClient.EnableSsl = $true
    $SMTPClient.Credentials = New-Object System.Net.NetworkCredential($senderEmail, $senderPassword)
    
    # # Send the email
    $SMTPClient.Send($email)
    Write-Host "Mail sent successfully with report attached."
    
}
catch {
    <#Do this if a terminating exception happens#>
}

 
 
